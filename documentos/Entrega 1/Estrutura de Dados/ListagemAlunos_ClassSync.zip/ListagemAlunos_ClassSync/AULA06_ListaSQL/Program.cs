﻿using ListagemAlunos_ClassSync;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

Console.OutputEncoding = System.Text.Encoding.UTF8;

string caminhoCsv = "Alunos.csv";
string caminhoBanco = "ClassSyncAlunos.db";
var repositorio = new AlunoDB(caminhoBanco);

Console.WriteLine("==================================================");
Console.WriteLine("        CLASSSYNC - PLATAFORMA INTEGRADA          ");
Console.WriteLine("   Projeto Integrador Interdisciplinar - KFKA    ");
Console.WriteLine("      Módulo: Análise de Estrutura de Dados       ");
Console.WriteLine("==================================================");
Console.WriteLine($"[INFO] Banco de Dados Inicializado: {caminhoBanco}");
Console.WriteLine();


if (!File.Exists(caminhoCsv))
{
    Console.WriteLine($"Arquivo CSV não encontrado. Certifique-se de que o 'Alunos.csv' está na pasta.");
    return;
}

int quantidadeImportada = ImportarCsv(caminhoCsv, repositorio);
Console.WriteLine($"Importação concluída com sucesso! Registros processados: {quantidadeImportada}");
Console.WriteLine("Pressione qualquer tecla para abrir o Painel de Paginação...");
Console.ReadKey();

List<Aluno> todosAlunos = repositorio.ObterTodos();

if (todosAlunos.Count == 0)
{
    Console.WriteLine("Nenhum registro de aluno encontrado no banco de dados.");
    return;
}

int itensPorPagina = 3;
int paginaAtual = 0;
int totalPaginas = (int)Math.Ceiling((double)todosAlunos.Count / itensPorPagina);

while (true)
{
    Console.Clear();
    Console.WriteLine("==================================================");
    Console.WriteLine($"    ClassSync - Listagem Paginada de Alunos       ");
    Console.WriteLine($"            Página {paginaAtual + 1} de {totalPaginas}            ");
    Console.WriteLine("==================================================");

    var alunosDaPagina = todosAlunos
                            .Skip(paginaAtual * itensPorPagina)
                            .Take(itensPorPagina)
                            .ToList();

    foreach (var aluno in alunosDaPagina)
    {
        Console.WriteLine(aluno.ToString());
    }

    Console.WriteLine("--------------------------------------------------");
    Console.WriteLine("[P] Próxima Página  |  [A] Página Anterior  |  [S] Sair");
    Console.WriteLine("--------------------------------------------------");
    Console.Write("Escolha uma opção de navegação: ");

    string opcao = Console.ReadLine()?.ToUpper() ?? "";

    if (opcao == "P" && paginaAtual < totalPaginas - 1) paginaAtual++;
    else if (opcao == "A" && paginaAtual > 0) paginaAtual--;
    else if (opcao == "S")
    {
        Console.WriteLine("\nSaindo do sistema de paginação. Bom trabalho!");
        break;
    }
}

Aluno convert(string[] item)
{
    string ra = item[0].Trim();
    string nome = item[1].Trim();
    string turma = item[2].Trim();

    return new Aluno(ra, nome, turma);
}

int ImportarCsv(string caminho, AlunoDB AppDB)
{
    int contador = 0;
    if (File.Exists(caminho))
    {
        using (StreamReader sr = new StreamReader(caminho))
        {
            string? linha = sr.ReadLine();
            while ((linha = sr.ReadLine()) != null)
            {
                if (string.IsNullOrWhiteSpace(linha)) continue;

                string[] colunas = linha.Split(';');
                if (colunas.Length >= 3)
                {
                    Aluno aluno = convert(colunas);
                    AppDB.InserirOuAtualizar(aluno);
                    contador++;
                }
            }
        }
    }
    return contador;
}

