﻿using System;
using System.Globalization;

namespace ListagemAlunos_ClassSync
{
    internal class Aluno 
    {
        public string RA { get; set; }
        public string Nome { get; set; }
        public string Turma { get; set; }

        public Aluno()
        {
        }

        public Aluno(string ra, string nome, string turma)
        {
            RA = ra;
            Nome = nome;
            Turma = turma;
        }

        public override string ToString()
        {
            return $"RA: {RA} | Nome: {Nome} | Turma: {Turma}";
        }
    }
}

