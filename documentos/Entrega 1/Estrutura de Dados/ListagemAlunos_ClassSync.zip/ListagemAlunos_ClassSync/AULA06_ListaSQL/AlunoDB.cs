﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;

namespace ListagemAlunos_ClassSync
{
    internal class AlunoDB
    {
        private readonly string _connectionString;

        public AlunoDB(string caminhoBanco)
        {
            _connectionString = $"Data Source={caminhoBanco}";
            CriarTabelaSeNaoExistir();
        }

        private void CriarTabelaSeNaoExistir()
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                CREATE TABLE IF NOT EXISTS Alunos (
                    RA     TEXT NOT NULL PRIMARY KEY,
                    Nome   TEXT NOT NULL,
                    Turma  TEXT NOT NULL
                );
            ";
            comando.ExecuteNonQuery();
        }

        public void Inserir(Aluno item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                INSERT INTO Alunos (RA, Nome, Turma)
                VALUES (@ra, @nome, @turma);
            ";
            comando.Parameters.AddWithValue("@ra", item.RA);
            comando.Parameters.AddWithValue("@nome", item.Nome);
            comando.Parameters.AddWithValue("@turma", item.Turma);

            comando.ExecuteNonQuery();
        }

        public void Atuallizar(Aluno item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                UPDATE Alunos
                   SET Nome  = @nome,
                       Turma = @turma
                 WHERE RA    = @ra;
            ";
            comando.Parameters.AddWithValue("@ra", item.RA);
            comando.Parameters.AddWithValue("@nome", item.Nome);
            comando.Parameters.AddWithValue("@turma", item.Turma);

            comando.ExecuteNonQuery();
        }

        public Aluno? ObterPorRA(string ra)
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                SELECT RA, Nome, Turma
                  FROM Alunos
                 WHERE RA = @ra;
            ";
            comando.Parameters.AddWithValue("@ra", ra);

            using var reader = comando.ExecuteReader();

            if (reader.Read())
            {
                return new Aluno
                {
                    RA = reader.GetString(0),
                    Nome = reader.GetString(1),
                    Turma = reader.GetString(2)
                };
            }

            return null;
        }

        public List<Aluno> ObterTodos()
        {
            var lista = new List<Aluno>();

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                SELECT RA, Nome, Turma
                  FROM Alunos
              ORDER BY Nome;
            ";

            using var reader = comando.ExecuteReader();
            while (reader.Read())
            {
                var aluno = new Aluno(reader.GetString(0), reader.GetString(1), reader.GetString(2));
                lista.Add(aluno);
            }

            return lista;
        }

        public void InserirOuAtualizar(Aluno item)
        {
            var existente = ObterPorRA(item.RA);

            if (existente == null)
                Inserir(item);
            else
                Atuallizar(item);
        }
    }
}


